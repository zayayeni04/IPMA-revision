# IPMA Level D — SAQ Flashcard Drill

An interactive active-recall flashcard app for the **IPMA Level D** short-answer (SAQ) paper, covering all six **Practice** competence elements mapped to the ICB4 KCIs:

| Code | Competence |
|------|------------|
| 4.5.4 | Time |
| 4.5.5 | Organisation & Information |
| 4.5.6 | Quality |
| 4.5.7 | Finance |
| 4.5.8 | Resources |
| 4.5.12 | Stakeholders |

39 cards, each with an exam-style model answer.

## Features

- **Flip to recall** — answer aloud from memory, then reveal the model answer.
- **Rate yourself** — Review / Almost / Mastered, tracked as a RAG progress bar.
- **Drill weak** mode — filters to everything not yet Mastered; cards drop out of the queue as you master them.
- **Filter by topic**, **shuffle**, and full **keyboard control**.
- **Progress persists** across sessions (browser storage).

### Keyboard

| Key | Action |
|-----|--------|
| `Space` | Flip card |
| `←` / `→` | Previous / next |
| `1` / `2` / `3` | Rate Review / Almost / Mastered |

## Run locally

Just open `index.html` in any browser — no build step, no dependencies.

## Publish to GitHub Pages

From this folder, after creating an **empty** repo on GitHub (no README/licence — this repo already has them):

```bash
git remote add origin https://github.com/<your-username>/ipma-saq-flashcards.git
git branch -M main
git push -u origin main
```

Then on GitHub: **Settings → Pages → Build and deployment → Source: Deploy from a branch → Branch: `main` / `root` → Save.**

Your live drill will appear at:

```
https://<your-username>.github.io/ipma-saq-flashcards/
```

Give it a minute on first deploy, then bookmark it on your phone for on-the-go revision.

## Note on content

The card content is revision material derived from the ICB4 syllabus for personal exam preparation. It is a study aid, not an official IPMA publication.
